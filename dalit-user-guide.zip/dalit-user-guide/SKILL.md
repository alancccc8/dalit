---
name: dalit-user-guide
description: Guide users through installing and using the Electron version of Dalit. Use when someone asks what Dalit is, how to install it, how to start it, how to open a local project, how Skills work, or what each major page in the desktop app does.
---

# Dalit User Guide

Use this skill when another AI application needs to explain the Electron desktop app version of Dalit to an end user.

Focus on practical onboarding, not implementation trivia. Keep the explanation friendly, concrete, and based on the current Electron project structure in `packages/desktop-electron` and the shared app routes in `packages/app`.

## What Dalit is

Describe Dalit as:

- A desktop AI workbench for local projects, documents, and repeatable workflows
- A product that wraps the OpenCode agent engine in an Electron shell
- A tool that works around a project folder instead of a single chat box

Good framing:

- "Dalit is better understood as an AI workspace for your local files."
- "You open a project folder, then let Dalit read, search, edit, summarize, automate, and reuse skills around that workspace."

Avoid saying:

- That it is "just a chatbot"
- That every page is production-stable
- That it provides hard sandbox isolation

## Source-backed facts to rely on

These are grounded in the current codebase and are safe to mention.

### Desktop shell

- The Electron app lives in `packages/desktop-electron`
- Main process, preload, and renderer are split under:
  - `src/main`
  - `src/preload`
  - `src/renderer`
- The app starts a local sidecar service before opening the main window
- The sidecar health endpoint is `/global/health`
- The desktop app registers deep links for both `dalit://` and `opencode://`

### Build and packaging

- Development script: `bun run --cwd packages/desktop-electron dev`
- Production build script: `bun run --cwd packages/desktop-electron build`
- Packaging scripts:
  - `bun run --cwd packages/desktop-electron package:win`
  - `bun run --cwd packages/desktop-electron package:mac`
  - `bun run --cwd packages/desktop-electron package:linux`
- Electron Builder outputs NSIS on Windows and DMG/ZIP or AppImage/DEB/RPM for other platforms

### Current desktop capabilities

- Open local folders and files with native pickers
- Open external links and local paths
- Show desktop notifications
- Read clipboard images
- Manage global and project-level Skills
- Check for app updates in packaged builds
- Handle WSL path conversion on Windows when enabled

### Current app routes

These routes exist in `packages/app/src/app.tsx`:

- `/` Home
- `/dashboard`
- `/dashboard/guide`
- `/skills`
- `/experts`
- `/automation-workshop`
- `/scheduled-tasks`
- `/turbo`
- `/my-dalit`
- `/help`
- `/:dir/session/:id?` project session workspace

### Skills behavior

- Full Skills management is desktop-specific
- Global skills are discovered from:
  - bundled preset skills
  - `~/.agents/skills`
  - `~/.claude/skills`
  - the app config skills directory
- Project skills live in `.opencode/skills` inside the current repository
- Project skill loading can be:
  - all discovered skills
  - only selected skills
- Desktop supports importing a skill package from:
  - a folder
  - a `SKILL.md`
  - a `.zip`

### Menu and shortcuts

The macOS app menu currently exposes:

- `New Session`
- `Open Project...`
- `New Window`
- `Toggle Sidebar`
- `Toggle Terminal`
- `Toggle File Tree`
- `Back / Forward`
- `Previous / Next Session`
- `Previous / Next Project`
- `Check for Updates...`
- `Install CLI...` on macOS and Linux only

Do not claim these exact native menu items exist on Windows unless the user only cares about functionality rather than menu placement.

## How to answer

Default answer flow:

1. Explain what Dalit is in one short paragraph
2. Explain how to install or start it
3. Explain the first-run path
4. Explain the page or feature the user asked about
5. Add a short safety note if the user may handle company or sensitive data

Prefer short, task-shaped guidance:

- "Open Dalit, choose a local folder, then start with one real task."
- "If you are handling internal data, switch to your company model endpoint before asking Dalit to analyze files."

## Installation guidance

Use one of the following depending on the user's intent.

### For normal end users

Recommend:

- Download the packaged Dalit desktop installer for the user's platform
- Launch the app and wait for the local service to finish starting
- If startup is slow or fails, check for:
  - old OpenCode or Dalit installs
  - antivirus or endpoint software blocking the local sidecar

### For developers building from source

Recommend:

```bash
bun install
bun run --cwd packages/desktop-electron dev
```

For packaged output:

```bash
bun run --cwd packages/desktop-electron package:win
bun run --cwd packages/desktop-electron package:mac
bun run --cwd packages/desktop-electron package:linux
```

Mention that Electron packaging is configured through [electron-builder.config.ts](../../electron-builder.config.ts) and the sidecar binary plus preset skills are bundled from `resources/`.

## First-run guidance

Recommend this order:

1. Open Dalit
2. Wait for the local sidecar service to initialize
3. Open a local folder as the working project
4. Confirm the model or server connection you want to use
5. Start with one concrete task instead of exploring every page first

Good starter prompts:

```text
请先帮我快速盘点这个项目目录里都有什么文件，并告诉我适合先做哪三件事。
```

```text
请读取当前工作区里的文档，整理一个“背景、问题、结论、待办”的摘要。
```

```text
请先理解这个代码仓库的结构，再告诉我从哪里开始改最安全。
```

## Feature guide

Use this section to explain the major pages and when to use them.

### Home

Use for:

- Understanding what Dalit can do
- Opening a local project quickly
- Starting from sample scenarios or a guided path

Explain it as the best place for first-time onboarding.

### Project sessions

Use for:

- The actual day-to-day work
- Chatting around a specific local folder
- Reading files, generating outputs, editing content, and continuing prior context

Explain that the session view is the core workspace, not a side feature.

### Skills Library

Use for:

- Managing reusable capabilities
- Importing skill packages from folders or zip files
- Separating machine-wide skills from project-specific skills

Important facts:

- Global skills are for the whole machine
- Project skills are stored in `.opencode/skills`
- Projects can load all detected skills or only a selected subset

### Experts

Use for:

- Bringing a more role-based or specialty-driven angle into the conversation
- Choosing a preset expert style before or during a task

Explain it as a way to narrow the assistant's perspective, not a separate AI engine.

### Scheduled Tasks

Use for:

- Recurring reminder-like or periodic tasks
- Routine checks and regular summaries

If the user asks whether this is fully mature, say it is useful for recurring workflows but should still be validated on real tasks before relying on it for critical operations.

### Automation Workshop

Use for:

- Designing repeatable multi-step office or knowledge workflows
- Turning repeated manual actions into a more structured process

Frame it as a productivity and workflow page, not just a settings screen.

### Turbo

Use for:

- Experimental or higher-automation workflows

If the current product behavior is unclear, say it is an advanced area intended for stronger automation scenarios and may evolve quickly.

### My Dalit

Use for:

- Seeing companion state and product personality features
- Looking at local usage statistics and heatmap-like views
- Making the product feel more personal and continuous over time

Do not oversell this as a mission-critical page; describe it as the user's personal/product insight area.

### Dashboard and guide pages

Use for:

- Overview-level entry
- Guided onboarding
- Product walk-throughs

### Help

Use for:

- Getting usage help inside the product
- Referring people to self-serve guidance when they are stuck

## Skills-specific guidance

When someone asks "How do Skills work?", answer in this order:

1. Skills are reusable instruction packs
2. They let Dalit or another AI agent behave more consistently on recurring tasks
3. Desktop Dalit can manage them visually
4. You can keep some global and some project-specific

Useful explanation:

- "Project = working scene"
- "Session = the current collaboration"
- "Skill = a reusable way of doing a class of tasks"

If the user asks where to store them:

- Global: `~/.agents/skills`
- Project: `.opencode/skills`

If the user asks how to import them:

- Import from a folder
- Import from a zip package
- Import from a skill package that contains `SKILL.md`

## Safety and compliance guidance

Always include a short caution when sensitive data may be involved:

- Prefer the company's approved model endpoint or gateway
- Avoid pasting secrets, personal data, or confidential material into ad hoc test models
- Review generated files or edits before using them as final output

If asked about hard isolation, say:

- Dalit includes permissions, approvals, and desktop controls
- but it should not be described as a hard security sandbox by itself

## Response templates

### Template: "How do I get started with Dalit?"

Answer shape:

- One sentence on what Dalit is
- Install or open the desktop app
- Open a local folder
- Pick the right model/server
- Start with one real task

### Template: "What does the Skills Library do?"

Answer shape:

- It is where reusable capabilities are managed
- You can import global or project-level skills
- Project skills stay with the repository in `.opencode/skills`
- Use it once you notice repeated task patterns

### Template: "How do I explain Dalit to a teammate?"

Answer shape:

- Dalit is an Electron desktop workspace for local AI-assisted work
- It opens around a project folder rather than a blank chat
- It supports reusable skills, role-style experts, recurring tasks, and personal usage views
- The product is strongest when used on a real local workflow

## Demo asset

If the user wants a visual overview, point them to:

`assets/dalit-feature-map.html`

That file is a standalone static product-intro page for the Electron version of Dalit.
